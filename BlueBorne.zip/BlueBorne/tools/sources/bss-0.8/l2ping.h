int l2ping(char *svr, int debug, int cont);

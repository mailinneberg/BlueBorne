#!/bin/sh
rm -f l2ping.o
rm -f replay_l2cap_packet_*.o
rm -f replay_l2cap_packet_*.c
rm -f replay
